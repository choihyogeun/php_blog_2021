<div id="footer_content">
    <p id="footer_logo"><a href="https://github.com/choihyogeun" target = "_blank"><img src="../img/img_sns_git.png">
    <a href="https://codepen.io/choihyogeun/pen/abpGzrx" target = "_blank"><img src="../img/img_sns_codepen.png">
    <a href="https://www.youtube.com/channel/UCPevxCCZZ5VJhw6TVqtiPCA" target = "_blank"><img src="../img/img_sns_youtube.png">
    <a href="https://codepen.io/choihyogeun/pen/abpGzrx" target = "_blank"><img src="../img/img_sns_write.png">
    <a href="https://codepen.io/choihyogeun/pen/abpGzrx" target = "_blank"><img src="../img/img_sns_setting.png"></span></p>

    <ul id="author">
        <li><img src="../img/img_intro.png"></li>
    </ul>
</div>