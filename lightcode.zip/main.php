    <!-- 메인 이미지 영역 -->

    <div id="main_img_bar">
        <img src="./img/main_img.jpg">
    </div>
    <!-- 이미지 아래 최신 게시글 표시 영역 -->
    <div id="main_content">
        <!-- 1. 최신 게시글 목록 -->
        <article id="latest">
            <h4>최신 게시글</h4>
            <ul></ul>
        </article>

        <!-- 2. 포인트 랭킹 목록
        <article id="point_rank">
            <h4>포인트 랭킹</h4>
            <ul></ul>
        </article> -->
    </div>